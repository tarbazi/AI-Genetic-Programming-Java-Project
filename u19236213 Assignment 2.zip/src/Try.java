public class Try{
    public static void main(String[] args){
       //int[][] arr = new int[20][5];
       System.out.println(System.currentTimeMillis());
       //System.out.println(arr[0].length);
    }
}